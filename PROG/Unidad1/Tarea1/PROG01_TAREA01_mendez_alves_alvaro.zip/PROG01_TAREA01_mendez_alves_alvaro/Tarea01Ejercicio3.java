class Tarea01Ejercicio3 {
	
	public static void main(String[] args) {
		System.out.println("IES AUGUSTOBRIGA"); 
		System.out.println("M\u00f3dulo Profesional - PROGRAMACI\u00d3N"); 
		System.out.println("TAREA 01 Introducci\u00f3n a la programaci\u00f3n"); 
		System.out.println(""); 
		System.out.println("Ejercicio 3 Trabajando con NETBEANS "); // comentario aclaratorio
		System.out.println(""); 
		System.out.println("\u00c1lvaro M\u00e9ndez Alves"); 
		System.out.println("Alburquerque - Badajoz"); 
	}
	
}